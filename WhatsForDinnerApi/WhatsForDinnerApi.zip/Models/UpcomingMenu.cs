﻿// UpcomingMenu.cs
using System.ComponentModel.DataAnnotations.Schema;

namespace WhatsForDinnerApi.Models
{
    [Table("UpcomingMenu")]
    public class UpcomingMenu
    {
        public int Id { get; set; }
        public int DishId { get; set; }

        // nav back to Dish
        public Dish Dish { get; set; } = null!;
    }
}
