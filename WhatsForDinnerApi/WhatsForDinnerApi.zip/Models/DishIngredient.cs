﻿// DishIngredient.cs
using System.ComponentModel.DataAnnotations.Schema;

namespace WhatsForDinnerApi.Models
{
    [Table("DishIngredients")]
    public class DishIngredient
    {
        public int DishId { get; set; }
        public int IngredientId { get; set; }
        public float Quantity { get; set; }
        public string QuantityType { get; set; } = null!;

        // navigation props
        public Dish Dish { get; set; } = null!;
        public Ingredient Ingredient { get; set; } = null!;
    }
}
