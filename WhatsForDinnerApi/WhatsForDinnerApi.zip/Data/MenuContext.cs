﻿using Microsoft.EntityFrameworkCore;
using WhatsForDinnerApi.Models;

public class MenuContext : DbContext
{
    public MenuContext(DbContextOptions<MenuContext> opts)
        : base(opts) { }

    public DbSet<Dish> Dishes { get; set; }
    public DbSet<Ingredient> Ingredients { get; set; }
    public DbSet<DishIngredient> DishIngredients { get; set; }
    public DbSet<UpcomingMenu> UpcomingMenu { get; set; }

    protected override void OnModelCreating(ModelBuilder mb)
    {
        // composite PK for the join‑table:
        mb.Entity<DishIngredient>()
          .HasKey(di => new { di.DishId, di.IngredientId });

        // wire up the FK relationships (optional—EF can usually infer)
        mb.Entity<DishIngredient>()
          .HasOne(di => di.Dish)
          .WithMany(d => d.DishIngredients)
          .HasForeignKey(di => di.DishId);

        mb.Entity<DishIngredient>()
          .HasOne(di => di.Ingredient)
          .WithMany()
          .HasForeignKey(di => di.IngredientId);
    }
}
