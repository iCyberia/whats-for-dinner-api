﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WhatsForDinnerApi.Data;
using WhatsForDinnerApi.Models;

namespace WhatsForDinnerApi.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class UpcomingMenuController : ControllerBase
    {
        private readonly MenuContext _context;

        public UpcomingMenuController(MenuContext context)
            => _context = context;

        // GET: api/upcomingmenu
        [HttpGet]
        public async Task<ActionResult<IEnumerable<UpcomingMenu>>> Get()
        {
            var list = await _context.UpcomingMenu
                .Include(u => u.Dish)
                  .ThenInclude(d => d.DishIngredients)
                    .ThenInclude(di => di.Ingredient)
                .ToListAsync();

            return Ok(list);
        }

        // POST: api/upcomingmenu/{dishId}
        [HttpPost("{dishId:int}")]
        public async Task<ActionResult<UpcomingMenu>> Post(int dishId)
        {
            var dish = await _context.Dishes.FindAsync(dishId);
            if (dish == null)
                return NotFound($"No dish with ID {dishId}");

            var item = new UpcomingMenu { DishId = dishId };
            _context.UpcomingMenu.Add(item);
            await _context.SaveChangesAsync();

            // Return 201 with a route back to GET
            return CreatedAtAction(nameof(Get), new { id = item.Id }, item);
        }

        // DELETE: api/upcomingmenu/{id}
        [HttpDelete("{id:int}")]
        public async Task<IActionResult> Delete(int id)
        {
            var item = await _context.UpcomingMenu.FindAsync(id);
            if (item == null)
                return NotFound();

            _context.UpcomingMenu.Remove(item);
            await _context.SaveChangesAsync();
            return NoContent();
        }
    }
}
