﻿using System.Collections.Generic;
using System.Linq;
using Microsoft.AspNetCore.Mvc;
using WhatsForDinnerApi.Data;
using WhatsForDinnerApi.Models;

namespace WhatsForDinnerApi.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class MealsController : ControllerBase
    {
        private readonly MenuContext _context;

        public MealsController(MenuContext context)
        {
            _context = context;
        }

        // GET: api/meals
        [HttpGet]
        public ActionResult<IEnumerable<Dish>> Get()
        {
            var dishes = _context.Dishes.ToList();
            return Ok(dishes);
        }
    }
}
